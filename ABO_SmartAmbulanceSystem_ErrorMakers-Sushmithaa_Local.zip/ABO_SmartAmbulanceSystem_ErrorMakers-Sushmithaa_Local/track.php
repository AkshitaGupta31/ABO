<html>
   <head>
      <style>
         #map {
         height: 100%;
         }
         html,
         body {
         height: 100%;
         margin: 0;
         padding: 0;
         }
      </style>
   </head>
   <body>
      <div id="map"></div>
   </body>
   <script async defer
   src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCx3r_wiZ7-uTaWFDWCMNojLjqrtm3D8xY&libraries=places&callback=initMap"></script>
   <script src="app1.js"></script>
</html>